import { Component } from '@angular/core';

@Component({
  selector: 'basic-sidenav',
  templateUrl: 'basic-sidenav.html',
  styleUrls: ['shared.scss'],
})
export class SidenavBasicComponent {}
