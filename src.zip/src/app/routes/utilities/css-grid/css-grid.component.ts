import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-utilities-css-grid',
  templateUrl: './css-grid.component.html',
  styleUrls: ['./css-grid.component.scss'],
})
export class UtilitiesCssGridComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
