declare const ApexCharts: any;
